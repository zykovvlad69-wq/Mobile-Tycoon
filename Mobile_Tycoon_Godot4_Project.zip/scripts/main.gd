extends Control

const SAVE_PATH = "user://mobile_tycoon.cfg"
const PHONE_NAMES = [
"iPhone 16 Pro","iPhone 15","iPhone 14 Pro Max","iPhone SE 2022","Galaxy S25 Ultra",
"Galaxy S24","Galaxy Z Fold 6","Galaxy Z Flip 6","Pixel 9 Pro","Pixel 8a",
"Xiaomi 15 Ultra","Xiaomi 14T Pro","Redmi Note 14 Pro","POCO F6","OnePlus 13",
"OnePlus 12R","Nothing Phone (2)","Nothing Phone (1)","Huawei Pura 70 Ultra","Huawei Mate  X6",
"Honor Magic 7 Pro","Honor 200 Pro","Motorola Edge 50 Ultra","Moto Razr 50","Sony Xperia 1 VI",
"ASUS ROG Phone 9","ASUS Zenfone 11","Realme GT 7 Pro","Oppo Find X8 Pro","Vivo X200 Pro",
"iQOO 13","Nokia XR21","Fairphone 5","Tecno Phantom V Fold","Infinix Zero 40",
"Meizu 21 Pro","ZTE Nubia Z60 Ultra","Red Magic 10 Pro","Lenovo Legion Y90","Black Shark 5 Pro",
"Vertu Signature","CAT S75","Google Pixel Fold","Galaxy A55","Redmi K80",
"iPhone 13 mini","iPhone 12 Pro","Galaxy Note 20 Ultra","OnePlus Open","Oppo Reno 12 Pro"
]
const RARITIES = ["Common","Rare","Epic","Legendary"]
const RARITY_COLORS = [Color("#aeb8c7"),Color("#43a8ff"),Color("#b26cff"),Color("#ffbf45")]
var balance: int = 50000
var level: int = 1
var xp: int = 0
var owned: Array = []
var wallpaper: int = 0
var current_app: String = "home"
var notice: String = ""
var notice_time: float = 0.0
var phone_index: int = 0
var rng := RandomNumberGenerator.new()
var root_ui: Control

func _ready():
	rng.randomize()
	load_game()
	build_ui()

func build_ui():
	for child in get_children(): child.queue_free()
	root_ui = Control.new()
	root_ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(root_ui)
	var bg = ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = [Color("#101322"),Color("#15102b"),Color("#102332"),Color("#2b1525"),Color("#17251b")][wallpaper%5]
	root_ui.add_child(bg)
	# Background decorative glows
	for i in range(3):
		var glow = ColorRect.new()
		glow.position = Vector2(80+i*290,30+i*55)
		glow.size = Vector2(260,220)
		glow.color = Color([Color("#35256b"),Color("#174b62"),Color("#612b48")][i],0.22)
		root_ui.add_child(glow)
	var header = HBoxContainer.new()
	header.position = Vector2(28,18); header.size = Vector2(904,45)
	root_ui.add_child(header)
	var title = label("MOBILE TYCOON",24,Color.WHITE)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	header.add_child(label("₽ "+format_money(balance),20,Color("#ffd66b")))
	header.add_child(label("  LV."+str(level)+"  •  "+str(xp)+" XP",16,Color("#a9b9ff")))
	var content = PanelContainer.new()
	content.position=Vector2(22,76); content.size=Vector2(916,438)
	content.add_theme_stylebox_override("panel",panel_style(Color("#171b2b"),Color("#3b4260"),18))
	root_ui.add_child(content)
	var margin=MarginContainer.new()
	margin.add_theme_constant_override("margin_left",18); margin.add_theme_constant_override("margin_right",18)
	margin.add_theme_constant_override("margin_top",14); margin.add_theme_constant_override("margin_bottom",14)
	content.add_child(margin)
	var body=VBoxContainer.new(); body.add_theme_constant_override("separation",12); margin.add_child(body)
	if current_app=="home": draw_home(body)
	elif current_app=="Containers": draw_containers(body)
	elif current_app=="Market": draw_market(body)
	elif current_app=="Vault": draw_vault(body)
	elif current_app=="Settings": draw_settings(body)
	elif current_app=="Bank": draw_bank(body)
	elif current_app=="Events": draw_events(body)
	elif current_app=="Profile": draw_profile(body)
	elif current_app=="Lab": draw_lab(body)
	elif current_app=="Auction": draw_auction(body)
	else: draw_generic(body)
	var bottom=HBoxContainer.new()
	bottom.position=Vector2(30,490); bottom.size=Vector2(900,35)
	root_ui.add_child(bottom)
	for app in ["⌂ Home","▣ Containers","▤ Market","▣ Vault","⚙ Settings"]:
		var b=button(app,Color("#252c45"))
		bottom.add_child(b)
		b.pressed.connect(func(): open_app(app.split(" ")[1] if app!="⌂ Home" else "home"))
	if notice_time>0:
		var toast=label(notice,15,Color("#ffe18a"))
		toast.position=Vector2(340,465); toast.size=Vector2(300,24); toast.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
		root_ui.add_child(toast)

func draw_home(body):
	var welcome=label("Добро пожаловать, коллекционер",22,Color.WHITE); body.add_child(welcome)
	var sub=label("Твой карманный бизнес смартфонов. Открывай, собирай, торгуй.",14,Color("#aeb9d7")); body.add_child(sub)
	var grid=GridContainer.new(); grid.columns=5; grid.add_theme_constant_override("h_separation",15); grid.add_theme_constant_override("v_separation",12); body.add_child(grid)
	var apps=[["Containers","Контейнеры","📦",Color("#7255d9")],["Market","Маркет","🛍",Color("#267bbd")],["Vault","Коллекция","▣",Color("#a17a32")],["Bank","Банк","₽",Color("#238e72")],["Events","Ивенты","✦",Color("#c34e58")],["Profile","Профиль","♙",Color("#4d6fba")],["Lab","Лаборатория","⚗",Color("#8b4bba")],["Auction","Аукцион","⚖",Color("#bd763c")],["Settings","Настройки","⚙",Color("#4a6079")],["Daily","Награды","★",Color("#c19c39")]]
	for app in apps:
		var card=Button.new(); card.custom_minimum_size=Vector2(150,112); card.text=""
		card.add_theme_stylebox_override("normal",panel_style(app[3],Color("#ffffff",0.12),14))
		card.add_theme_stylebox_override("hover",panel_style(app[3].lightened(0.15),Color("#ffffff",0.3),14))
		var box=VBoxContainer.new(); box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); box.alignment=BoxContainer.ALIGNMENT_CENTER
		var ic=label(app[2],29,Color.WHITE); ic.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; box.add_child(ic)
		var nm=label(app[1],15,Color.WHITE); nm.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; box.add_child(nm)
		card.add_child(box); grid.add_child(card)
		card.pressed.connect(func(): open_app(app[0]))

func draw_containers(body):
	body.add_child(label("КОНТЕЙНЕРЫ  /  КРУТИ И ЗАБИРАЙ",22,Color.WHITE))
	body.add_child(label("Каждое открытие стоит 2 500 ₽. Редкость определяет цену и шанс.",14,Color("#aeb9d7")))
	var row=HBoxContainer.new(); row.add_theme_constant_override("separation",18); body.add_child(row)
	for name in ["Стартовый","Техно","Премиум","Хэллоуин"]:
		var p=PanelContainer.new(); p.custom_minimum_size=Vector2(205,190); p.add_theme_stylebox_override("panel",panel_style(Color("#242c46"),Color("#515d86"),15)); row.add_child(p)
		var v=VBoxContainer.new(); v.alignment=BoxContainer.ALIGNMENT_CENTER; p.add_child(v)
		var art=label("⬡",48,Color("#b99aff")); art.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; v.add_child(art)
		var l=label(name,18,Color.WHITE); l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; v.add_child(l)
		var btn=button("ОТКРЫТЬ • 2 500 ₽",Color("#6651bc")); v.add_child(btn)
		btn.pressed.connect(func(): open_case(name))

func draw_market(body):
	body.add_child(label("МАРКЕТ СМАРТФОНОВ",22,Color.WHITE))
	body.add_child(label("Покупай модели, собирай коллекцию и перепродавай с выгодой.",14,Color("#aeb9d7")))
	var scroll=ScrollContainer.new(); scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL; body.add_child(scroll)
	var grid=GridContainer.new(); grid.columns=4; grid.add_theme_constant_override("h_separation",10); grid.add_theme_constant_override("v_separation",10); scroll.add_child(grid)
	for i in range(PHONE_NAMES.size()):
		var cost=price_for(i)
		var card=PanelContainer.new(); card.custom_minimum_size=Vector2(205,120); card.add_theme_stylebox_override("panel",panel_style(Color("#20283e"),RARITY_COLORS[i%4],12)); grid.add_child(card)
		var v=VBoxContainer.new(); v.add_theme_constant_override("separation",4); card.add_child(v)
		v.add_child(label("▯  "+PHONE_NAMES[i],14,Color.WHITE))
		v.add_child(label(RARITIES[i%4]+"  •  "+format_money(cost),12,RARITY_COLORS[i%4]))
		var b=button("Купить",Color("#315c92")); v.add_child(b)
		b.pressed.connect(func(): buy_phone(i,cost))

func draw_vault(body):
	body.add_child(label("МОЯ КОЛЛЕКЦИЯ",22,Color.WHITE))
	body.add_child(label("Смартфонов собрано: "+str(owned.size()),14,Color("#aeb9d7")))
	if owned.is_empty():
		body.add_child(label("Пока пусто. Загляни в контейнеры или маркет!",18,Color("#ffe18a")))
	else:
		var scroll=ScrollContainer.new(); scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL; body.add_child(scroll)
		var grid=GridContainer.new(); grid.columns=4; grid.add_theme_constant_override("h_separation",12); grid.add_theme_constant_override("v_separation",10); scroll.add_child(grid)
		for item in owned:
			var i=int(item)
			var card=PanelContainer.new(); card.custom_minimum_size=Vector2(205,100); card.add_theme_stylebox_override("panel",panel_style(Color("#252c44"),RARITY_COLORS[i%4],12)); grid.add_child(card)
			var v=VBoxContainer.new(); card.add_child(v); v.add_child(label("▯  "+PHONE_NAMES[i],14,Color.WHITE)); v.add_child(label("Цена: "+format_money(price_for(i)),12,RARITY_COLORS[i%4]))
			var sell=button("Продать +"+format_money(int(price_for(i)*0.82)),Color("#8d4656")); v.add_child(sell)
			sell.pressed.connect(func(): sell_phone(i))

func draw_settings(body):
	body.add_child(label("НАСТРОЙКИ",22,Color.WHITE))
	body.add_child(label("Персонализируй домашний экран.",14,Color("#aeb9d7")))
	var row=HBoxContainer.new(); row.add_theme_constant_override("separation",12); body.add_child(row)
	for i in range(5):
		var b=button(["Обои • Ночь","Обои • Неон","Обои • Океан","Обои • Рубин","Обои • Лес"][i],Color(["#25213f","#202d49","#183c4c","#482537","#243d2b"][i]))
		row.add_child(b); b.pressed.connect(func(): wallpaper=i; save_game(); build_ui())
	var reset=button("Сбросить прогресс",Color("#873c4c")); body.add_child(reset)
	reset.pressed.connect(func(): balance=50000; level=1; xp=0; owned=[]; save_game(); build_ui())

func draw_bank(body):
	body.add_child(label("МОБИЛЬНЫЙ БАНК",22,Color.WHITE)); body.add_child(label("Баланс: "+format_money(balance),20,Color("#ffd66b")))
	var daily=button("Получить ежедневный бонус • 1 500 ₽",Color("#287d69")); body.add_child(daily)
	daily.pressed.connect(func(): balance+=1500; gain_xp(15); notify("Бонус начислен: +1 500 ₽"); save_game(); build_ui())

func draw_events(body):
	body.add_child(label("СЕЗОННЫЕ СОБЫТИЯ",22,Color.WHITE))
	body.add_child(label("🎃 ХЭЛЛОУИН • ограниченный контейнер • тематические модели",18,Color("#ff9b56")))
	body.add_child(label("Зимний фестиваль • Неоновая неделя • Тайный запуск",15,Color("#b9a7ff")))
	var b=button("Забрать ивент-бонус • 3 000 ₽",Color("#9b5632")); body.add_child(b)
	b.pressed.connect(func(): balance+=3000; gain_xp(30); notify("Ивент-бонус получен"); save_game(); build_ui())

func draw_profile(body):
	body.add_child(label("ПРОФИЛЬ КОЛЛЕКЦИОНЕРА",22,Color.WHITE))
	body.add_child(label("Уровень "+str(level)+"   •   "+str(xp)+" XP",18,Color("#b9a7ff")))
	body.add_child(label("Коллекция: "+str(owned.size())+" смартфонов",16,Color.WHITE))
	body.add_child(label("Общая стоимость: "+format_money(collection_value()),16,Color("#ffd66b")))
	body.add_child(label("Статус: начинающий магнат",14,Color("#aeb9d7")))

func draw_lab(body):
	body.add_child(label("СЕКРЕТНАЯ ЛАБОРАТОРИЯ",22,Color.WHITE))
	body.add_child(label("Экспериментальные модели. Риск, редкость и высокая стоимость.",14,Color("#aeb9d7")))
	var b=button("Синтезировать прототип • 8 000 ₽",Color("#7447a2")); body.add_child(b)
	b.pressed.connect(func():
		if balance>=8000:
			balance-=8000
			var i=rng.randi_range(0,PHONE_NAMES.size()-1)
			owned.append(i); gain_xp(100); notify("Прототип получен: "+PHONE_NAMES[i]); save_game(); build_ui()
		else: notify("Недостаточно средств"); build_ui()
	)

func draw_auction(body):
	body.add_child(label("АУКЦИОН",22,Color.WHITE))
	body.add_child(label("Симулятор торгов: выставляй смартфоны на продажу по повышенной цене.",14,Color("#aeb9d7")))
	var b=button("Провести быстрые торги • 4 000 ₽ вход",Color("#8b5b32")); body.add_child(b)
	b.pressed.connect(func():
		if balance>=4000:
			balance-=4000
			var reward=rng.randi_range(5000,12000); balance+=reward; gain_xp(50)
			notify("Итог торгов: "+format_money(reward)); save_game(); build_ui()
		else: notify("Нужно 4 000 ₽"); build_ui()
	)

func draw_generic(body):
	body.add_child(label("ПРИЛОЖЕНИЕ",22,Color.WHITE))
	body.add_child(button("Вернуться на главный экран",Color("#394b70")))

func open_case(case_name):
	if balance<2500: notify("Недостаточно денег"); build_ui(); return
	balance-=2500
	var roll=rng.randf()
	var rarity=0
	if roll>0.90: rarity=3
	elif roll>0.70: rarity=2
	elif roll>0.40: rarity=1
	var i=rng.randi_range(0,PHONE_NAMES.size()-1)
	owned.append(i); gain_xp(35+rarity*40)
	notify(case_name+" • "+RARITIES[rarity]+" • "+PHONE_NAMES[i])
	save_game(); build_ui()

func buy_phone(i,cost):
	if owned.has(i): notify("Эта модель уже есть в коллекции")
	elif balance<cost: notify("Недостаточно средств")
	else: balance-=cost; owned.append(i); gain_xp(20); notify("Куплен "+PHONE_NAMES[i])
	save_game(); build_ui()

func sell_phone(i):
	var idx=owned.find(i)
	if idx>=0:
		owned.remove_at(idx); balance+=int(price_for(i)*0.82); gain_xp(10); notify("Продан "+PHONE_NAMES[i])
	save_game(); build_ui()

func gain_xp(amount):
	xp+=amount
	while xp>=level*250:
		xp-=level*250; level+=1; balance+=level*1000; notify("Новый уровень! "+str(level))

func price_for(i): return 1500+(i*137)%25000+((i%4)*3200)
func collection_value():
	var total=0
	for i in owned: total+=price_for(int(i))
	return total
func format_money(value): return "%s ₽" % ("{0}".format([value]))
func open_app(app): current_app=app; build_ui()
func notify(msg): notice=msg; notice_time=2.0

func label(text_value,size,color):
	var l=Label.new(); l.text=str(text_value); l.add_theme_font_size_override("font_size",size); l.add_theme_color_override("font_color",color); l.vertical_alignment=VERTICAL_ALIGNMENT_CENTER; return l
func button(text_value,color):
	var b=Button.new(); b.text=text_value; b.custom_minimum_size=Vector2(130,36)
	b.add_theme_stylebox_override("normal",panel_style(color,Color("#ffffff",0.12),9))
	b.add_theme_stylebox_override("hover",panel_style(color.lightened(0.12),Color("#ffffff",0.24),9))
	b.add_theme_color_override("font_color",Color.WHITE); return b
func panel_style(color,border,radius):
	var s=StyleBoxFlat.new(); s.bg_color=color; s.border_color=border; s.set_border_width_all(1); s.set_corner_radius_all(radius); s.content_margin_left=10; s.content_margin_right=10; s.content_margin_top=8; s.content_margin_bottom=8; return s

func save_game():
	var cfg=ConfigFile.new()
	cfg.set_value("game","balance",balance); cfg.set_value("game","level",level); cfg.set_value("game","xp",xp)
	cfg.set_value("game","owned",owned); cfg.set_value("game","wallpaper",wallpaper)
	cfg.save(SAVE_PATH)
func load_game():
	var cfg=ConfigFile.new()
	if cfg.load(SAVE_PATH)==OK:
		balance=int(cfg.get_value("game","balance",50000)); level=int(cfg.get_value("game","level",1)); xp=int(cfg.get_value("game","xp",0))
		owned=cfg.get_value("game","owned",[]); wallpaper=int(cfg.get_value("game","wallpaper",0))
